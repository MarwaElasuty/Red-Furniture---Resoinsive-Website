// (function ($) {
//   "use strict";
  
  
//   // Initiate the wowjs
//   new WOW().init();


  
// })(jQuery);